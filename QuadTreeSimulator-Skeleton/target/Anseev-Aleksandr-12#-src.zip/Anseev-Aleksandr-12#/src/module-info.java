module particlelocator {
	exports quadtreesimulator;
	
	requires transitive javafx.graphics;
	requires transitive javafx.controls;
	requires javafx.base;
}